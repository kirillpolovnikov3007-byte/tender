"""Этапы pipeline Rostender Parser."""
